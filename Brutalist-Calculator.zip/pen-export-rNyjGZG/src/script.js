function displaynum(n1) {
  Calculator.txt1.value=Calculator.txt1.value + n1;
}